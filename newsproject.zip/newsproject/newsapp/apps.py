from django.apps import AppConfig


class NewsappConfig(AppConfig):
    name = 'newsapp'
